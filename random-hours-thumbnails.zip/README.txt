Random Hours portfolio thumbnail assets
========================================

Copy the files in assets/ into the portfolio repository's assets/ folder.
These are compressed WebP versions of the supplied screenshots.

Mapping:
01-ganpati-visarjan-mumbai.webp — Ganpati Visarjan, Mumbai (video)
02-ganpati-visarjan-photography.webp — Ganpati Visarjan, Mumbai (photography)
03-pat-cafe-sign.webp — Pat Bakery Café sign
04-ganpati-aagman-pune-photo.webp — Ganpati Aagman, Pune (photography)
05-ganpati-aagman-pune-video.webp — Ganpati Aagman, Pune (video)
06-vit-pune.webp — VIT, Pune
07-silent-patient-product-photo.webp — The Silent Patient (product photography)
08-working-hour-chets.webp — The Working Hour featuring Chets
09-denver-product-photo.webp — Denver (product photography)
10-gamble-trailer.webp — GAMBLE trailer
11-gamble-teaser.webp — GAMBLE teaser
12-pehchaan-tu-promo-3.webp — Pehchaan Tu Promo 3
13-pehchaan-tu-promo-2.webp — Pehchaan Tu Promo 2
14-pehchaan-tu-promo-1.webp — Pehchaan Tu Promo 1

Note: the thumbnail files are optimized; the existing Instagram destination URLs still need to be mapped to each card in index.html.
